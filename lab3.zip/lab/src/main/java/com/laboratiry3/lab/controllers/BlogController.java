package com.laboratiry3.lab.controllers;

import com.laboratiry3.lab.models.Post;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.laboratiry3.lab.repo.PostRepository;

@Controller
public class BlogController
{
    @Autowired
    private PostRepository postRepository;

    @GetMapping("/blog")
    public String blogmain(Model model){
        Iterable<Post> posts = postRepository.findAll();
        model.addAttribute("posts", posts);
        return "blog-main";
    }
}

