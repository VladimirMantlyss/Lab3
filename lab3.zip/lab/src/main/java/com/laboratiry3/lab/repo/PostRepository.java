package com.laboratiry3.lab.repo;

import com.laboratiry3.lab.models.Post;
import org.springframework.data.repository.CrudRepository;

public interface PostRepository extends CrudRepository<Post, Long>
{
}
