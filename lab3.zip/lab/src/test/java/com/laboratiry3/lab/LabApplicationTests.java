package com.laboratiry3.lab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabApplicationTests {

    @Test
    void contextLoads() {
    }

}
